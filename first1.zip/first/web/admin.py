from django.contrib import admin
from . models import Table,Pageadd
# Register your models here.

admin.site.register(Table)
# admin.site.register(Contact)
admin.site.register(Pageadd)

from django.contrib import admin
from .models import Contact

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'email', 'subject')
