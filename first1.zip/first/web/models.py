from django.db import models
from versatileimagefield.fields import VersatileImageField
from tinymce.models import HTMLField
from django.core.validators import EmailValidator

# Create your models here.

class Table(models.Model):
    name = models.CharField(max_length=100,blank=True,null=True)
    image = VersatileImageField(upload_to = "gallery")
    detail= HTMLField()


    def __str__(self):
        return self.name
    

class Contact(models.Model):
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    subject=models.CharField(max_length=50)
    message=models.TextField()
    timestamp = models.DateTimeField(db_index=True,auto_now_add=True)
    
    def __str__(self):
        return self.name
    


class Pageadd(models.Model):
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=15)
    email = models.EmailField(validators=[EmailValidator()])
    subject = models.CharField(max_length=255, blank=True)
    message = models.TextField()
    image = models.ImageField(upload_to='', blank=True, null=True)


    def __str__(self):
        return self.name
    


class Contact(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    subject = models.CharField(max_length=100, blank=True)
    message = models.TextField()
    image = models.ImageField(upload_to='contact/', blank=True)

    def __str__(self):
        return self.name
