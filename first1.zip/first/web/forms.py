from django import forms
from .models import Contact


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ('name', 'phone', 'email', 'subject', 'message', 'image')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Your Name', 'required': True})
        self.fields['phone'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Your Phone', 'required': True})
        self.fields['email'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Your Email', 'required': True})
        self.fields['subject'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Your Subject'})
        self.fields['message'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Your Message', 'rows': 5, 'required': True})
        self.fields['image'].widget.attrs.update({'class': 'form-control', 'id': 'image', 'required': False})
