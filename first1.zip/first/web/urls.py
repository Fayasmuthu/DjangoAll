from django.urls import path
from . import views


app_name = "web"

urlpatterns = [
    path("", views.index, name="index"),
    path("add/<int:id>", views.add, name="add"),

    path("pageadd", views.pageadd, name="pageadd"),
    path("pageget", views.pageget, name="pageget"),
    path("formget", views.formget, name="formget"),


]