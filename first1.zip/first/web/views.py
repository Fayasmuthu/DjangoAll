from django.shortcuts import render
from web.models import Table


from django.shortcuts import render
from django.http import HttpResponse


from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from .models import Pageadd


# Create your views here.

def index(request):
    table=Table.objects.all()

    context={"is_index": True,"table":table}

    return render(request,'web/index.html',context)


def add(request,id):
    table=Table.objects.get(id=id)
    context={"table":table}

    return render(request,'web/add.html',context)




def pageadd(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message')
        
        # Handle file upload
        image = request.FILES.get('image')
        if image:
            fs = FileSystemStorage()
            filename = fs.save(image.name, image)
            uploaded_file_url = fs.url(filename)
        else:
            uploaded_file_url = None

        contact = Pageadd(name=name, phone=phone, email=email, subject=subject, message=message, image=uploaded_file_url)
        contact.save()
        
        messages.success(request, 'Your message has been sent!')
        # return redirect('pageadd')

   
    context={}
    return render(request, 'web/pageadd.html', context)

def pageget(request):

    pageget=Pageadd.objects.all()
   
    context={"pageget":pageget}

    return render(request,'web/pageget.html',context)


# def formget(request):


#     return render(request,'web/formaddget.html')



from .forms import ContactForm

def formget(request):
    if request.method == 'POST':
        form = ContactForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse('Thank you for your message!')
    else:
        form = ContactForm()
    return render(request, 'web/formaddget.html', {'form': form})
